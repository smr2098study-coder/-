# 不改内容的格式清理

这是一份用户明确追加的要求，覆盖旧版保留标题 `keepNext`/`keepLines` 的默认行为。它与师门Word排版属于同一技能的清理模式，不新增另一个会竞争同一任务的技能。PPT技能仍然独立。

## 十项要求

1. 正文不得使用项目符号、无序列表或隐藏列表编号。
2. 清除所有正文的numbering/`numPr`，并清除样式和默认值中的继承来源；包含 `numId=0` 取消编号节点。标题也不使用自动编号。
3. 所有标题和正文均取消Keep with next（与下段同页）、Keep lines together（段中不分页）、Page break before（段前分页）。
4. 可以保留Heading 1、Heading 2等样式及大纲级别，但修改样式本身及其继承链，不让三项属性再次生效。
5. 正文使用普通段落，不使用List Bullet、List Number等列表样式；转换时保留其余字体、字号和段落格式。
6. 保留“第一章”“一、”“（一）”等原有章节文字编号，不改编号体系或标题层级，不使用Word自动编号。原为自动编号时先核对并转成普通文字，特别保护参考文献的可见序号。
7. 章节确需另起一页时使用真正的Page Break（`w:br w:type="page"`），不再用段前分页属性。纯格式清理保留既有真实分页符，不凭空添加章节分页。
8. 完成后检查paragraph properties及样式、默认值，确认 `keepNext`、`keepLines`、`pageBreakBefore`、`numPr` 无残留，包括false/0节点。
9. 在Word中打开 ¶ 后，段落左侧不再显示由这三项分页属性产生的小黑方块。不能关闭编辑标记来冒充修复；实际Word界面验证尚未完成时只报告结构证据。
10. 只清理指定格式，不改原文、参考文献、标题层级及表格内容，不改字体字号、其他缩进、页面边距和分节设计，不整理写作提示，不重建纯文本DOCX。

## 工具与检查

```text
python scripts/word_format.py clean-format original.docx --out cleaned.docx
python scripts/word_format.py audit cleaned.docx --format-only --out audit.json
```

`clean-format`直接处理OOXML，清理段落、样式和默认值。保留编号定义部件中未被使用的定义，不删除 `numbering.xml` 整个文件或破坏关系文件；验收看段落与样式中的 `numPr`、有效编号和列表样式。

如果输入有未转成文字的可见数字自动编号，脚本在写出文件前停止；这保护了用户第10条，不是允许遗漏清理。先由文档工具准确物化可见序号及其分隔符，再执行清理；不能猜序号、改变编号序列或丢掉参考文献序号。生成的项目符号可以作为列表格式清除；实际写在 `w:t` 中的黑点、连字符或专业符号是内容，不能批量删字。

本段“可见数字自动编号”只指段落列表编号。真实Footnote/Endnote编号、正文 `w:footnoteReference`/`w:endnoteReference`、note内 `w:footnoteRef`/`w:endnoteRef`、NOTEREF、书签及引用关系必须保留，不能转成普通文字来通过清理。Mode B尾注段落的baseline标记、Tab和悬挂缩进不套正文首行缩进。仅用户明确选择引用模式时，按[引用模式与验收](citation-modes.md)进行该模式允许的引用结构变更。

对比清理前后的全部文本节点、标题样式/大纲级别、表格文字、引用与其他域、图片关系、页眉页脚、脚注和分节符。删除三项分页设置会允许标题与后文分开，因此仍要视觉检查；不要因为发现孤立标题而恢复被禁止的属性。可在用户授权的范围内使用真实分页符安排章节。
